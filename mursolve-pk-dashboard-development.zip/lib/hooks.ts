'use client'

import useSWR from 'swr'
import type { Problem, Submission } from './problems'

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message)
  }
}

export async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...init?.headers },
    credentials: 'same-origin',
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new ApiError(data?.error ?? 'Request failed', res.status)
  return data as T
}

const fetcher = <T,>(url: string) => api<T>(url)

export function useProblems(fallback: Problem[]) {
  return useSWR<{ problems: Problem[] }>('/api/problems', fetcher, {
    fallbackData: { problems: fallback },
    revalidateOnFocus: false,
  })
}

export function useAdminSession() {
  return useSWR<{ authenticated: boolean; configured: boolean }>('/api/admin/session', fetcher, {
    revalidateOnFocus: true,
  })
}

export interface RawConfig {
  source: string
  columns: string[]
  rows: Record<string, string | number>[]
  pendingSubmissions: Submission[]
}

export function useAdminConfig(enabled: boolean) {
  return useSWR<RawConfig>(enabled ? '/api/admin/config' : null, fetcher)
}
