export const CATEGORIES = [
  'FinTech',
  'E-Commerce',
  'Logistics',
  'Gig Economy',
  'Compliance',
  'Infrastructure',
] as const

export type Category = (typeof CATEGORIES)[number]

export interface ProblemScores {
  severity: number
  tam: number
  whitespace: number
  frequency: number
}

export interface Problem {
  id: string
  title: string
  category: Category
  description: string
  source: string
  scores: ProblemScores
  /** Final Friction Index, 0–10 with one decimal. */
  frictionIndex: number
  /** True when an admin has manually set frictionIndex after load. */
  frictionOverridden: boolean
  upvotes: number
  createdAt: string
}

export interface Submission {
  id: string
  title: string
  category: Category
  details: string
  contact: string
  createdAt: string
}

/**
 * Row shape expected from an external data sheet (Google Sheets / CSV / Airtable).
 * Column headers map 1:1 to these keys; every field arrives as a string or number.
 */
export interface SheetRow {
  id?: string | number
  title: string
  category: string
  description?: string
  source?: string
  severity: string | number
  tam: string | number
  whitespace: string | number
  frequency: string | number
  friction_index?: string | number
  upvotes?: string | number
}

export const SHEET_COLUMNS: (keyof SheetRow)[] = [
  'id',
  'title',
  'category',
  'description',
  'source',
  'severity',
  'tam',
  'whitespace',
  'frequency',
  'friction_index',
  'upvotes',
]

export function computeFrictionIndex(scores: ProblemScores): number {
  const { severity, tam, whitespace, frequency } = scores
  return roundOne((severity + tam + whitespace + frequency) / 4)
}

function roundOne(n: number): number {
  return Math.round(n * 10) / 10
}

export function clampScore(value: unknown): number {
  const n = Number(value)
  if (!Number.isFinite(n)) return 0
  return roundOne(Math.min(10, Math.max(0, n)))
}

function clampCount(value: unknown): number {
  const n = Number(value)
  if (!Number.isFinite(n)) return 0
  return Math.max(0, Math.round(n))
}

export function isCategory(value: unknown): value is Category {
  return typeof value === 'string' && (CATEGORIES as readonly string[]).includes(value)
}

export function problemFromSheetRow(row: SheetRow, index: number): Problem | null {
  const title = String(row.title ?? '').trim()
  if (!title || !isCategory(row.category)) return null
  const scores: ProblemScores = {
    severity: clampScore(row.severity),
    tam: clampScore(row.tam),
    whitespace: clampScore(row.whitespace),
    frequency: clampScore(row.frequency),
  }
  const hasSheetIndex = row.friction_index !== undefined && row.friction_index !== ''
  return {
    id: String(row.id ?? `sheet-${index + 1}`),
    title: title.slice(0, 240),
    category: row.category,
    description: String(row.description ?? '').trim().slice(0, 1200),
    source: String(row.source ?? '').trim().slice(0, 200),
    scores,
    frictionIndex: hasSheetIndex ? clampScore(row.friction_index) : computeFrictionIndex(scores),
    frictionOverridden: false,
    upvotes: clampCount(row.upvotes ?? 0),
    createdAt: new Date().toISOString(),
  }
}

type SeedTuple = [
  title: string,
  category: Category,
  description: string,
  source: string,
  scores: [severity: number, tam: number, whitespace: number, frequency: number, friction: number],
  upvotes: number,
]

const SEED: SeedTuple[] = [
  [
    'Digital Wallet Payment Chain Freezes & Arbitrary Account Blocks',
    'FinTech',
    'Mobile money platforms (Easypaisa/SadaPay) implementing automated fraud triggers that freeze entire transactional chains, locking innocent downstream user funds without prior investigation.',
    'Facebook/Reddit Community Logs',
    [9.1, 9.5, 6.8, 8.2, 8.4],
    512,
  ],
  [
    'Prepaid Food Delivery Cancellations Without Automated Refund Reversals',
    'Logistics',
    'On-demand platforms (Foodpanda) allowing restaurants to cancel orders due to item unavailability but failing to automate the refund loop back to mobile wallets, forcing manual tracking by users.',
    'r/pakistan Dispute Threads',
    [8.2, 8.8, 6.0, 7.9, 7.7],
    341,
  ],
  [
    "E-Commerce Courier Status Manipulation (False Delivery Flags)",
    'E-Commerce',
    "Last-mile delivery riders manipulating app states by marking cash-on-delivery parcels as 'Delivered' or 'Customer Refused' before physical arrival to manage internal performance quotas.",
    'Voice of Customer Pakistan',
    [7.8, 9.2, 5.5, 8.5, 7.7],
    366,
  ],
  [
    'Biometric Account Lockouts & NADRA Synchronization Latency',
    'Compliance',
    'Digital banking applications dropping connection tokens and throwing biometric mismatches during user updates due to latency bugs between central compliance networks.',
    'Tech News Pakistan',
    [8.5, 7.9, 5.0, 6.8, 7.0],
    198,
  ],
  [
    'Freelance Cross-Border Escrow Multi-Tier FX Fee Leakage',
    'Gig Economy',
    "The world's 4th largest freelance node lacking domestic onboarding options, forcing local builders to drop 4% to 7% of earnings on multi-step intermediary platforms (Payoneer/Wise).",
    'r/PakistaniTech Ecosystem Data',
    [9.5, 8.4, 7.9, 8.6, 8.6],
    587,
  ],
  [
    'Local Debit Card Rejection Rates on Global Core SaaS Infrastructure',
    'FinTech',
    'Pakistani commercial bank debit/credit cards facing widespread declines when authenticating recurrent payments for vital international infrastructure (OpenAI, AWS, GitHub).',
    'Twitter Tech Rants',
    [8.9, 8.0, 7.2, 8.1, 8.0],
    463,
  ],
  [
    'Opaque E-Commerce Reverse Logistics & 14-Day Return Bottlenecks',
    'E-Commerce',
    'Major market aggregators (Daraz) running highly inconsistent return tracking nodes, forcing vendors and consumers into long, manual processing loops for damaged items.',
    'Consumer Redressal Complaints',
    [7.4, 8.9, 5.2, 7.1, 7.1],
    224,
  ],
  [
    'Automated Chatbot Gatekeeping in Digital Service Failure Disputes',
    'Infrastructure',
    'Retail applications using hard-coded AI bots that block users from reaching real agents during active financial transaction failures, causing dispute stalemates.',
    'r/developersPak Research',
    [7.9, 8.5, 6.4, 7.6, 7.6],
    287,
  ],
  [
    'Micro-SME Credit Scoring Deficit for Non-Collateral Tech Loans',
    'Compliance',
    'Traditional banking frameworks operating on legacy conservative brick-and-mortar parameters, preventing early-stage software and digital firms from securing expansion capital.',
    'State Bank Policy Review',
    [8.7, 7.2, 7.8, 5.9, 7.4],
    176,
  ],
  [
    'PandaMart Fresh Produce Quality Deficits & Pro-Tier Refund Failures',
    'Logistics',
    'Rapid e-grocery hubs distributing rotten goods and completely spoiled inventories, with customer support loops refusing compensation despite active premium tier memberships.',
    'Verified Consumer Forum Audio/Text Proof',
    [7.0, 8.3, 5.9, 7.4, 7.1],
    209,
  ],
  [
    'SadaPay High-Volume Transaction Blackouts & Obscure Failure Codes',
    'FinTech',
    'High-growth EMI platforms throwing unmapped error codes during runtime and leaving users with unaccessible operational cash balances due to ledger sync lapses.',
    'Live Startup Pakistan Tracker',
    [8.8, 8.1, 6.2, 6.9, 7.5],
    254,
  ],
  [
    'Warehouse Vendor Intake Rejections & Dynamic Rating Penalties',
    'E-Commerce',
    'Central distribution yards refusing stock drops over minor transport disputes, inducing unearned negative store ratings for independent e-commerce merchants.',
    'Facebook Merchant Support Groups',
    [7.6, 6.8, 6.7, 5.8, 6.7],
    118,
  ],
  [
    'AgriTech Supply Chain Disintermediation & Middlemen Margin Inflation',
    'Infrastructure',
    'Lack of cold-chain tracking networks and direct farm-to-retail tech pipelines, causing rural producers to lose massive revenue cuts to manipulative middlemen networks.',
    'Agri-Startup Whitepapers',
    [9.3, 9.0, 8.1, 8.9, 8.8],
    604,
  ],
  [
    'Blue-Collar Gig Economy Verification & Trust-Deficit Tracking',
    'Infrastructure',
    'Fragmentation of home-maintenance services leading to zero standardized tracking for background checks, making onboarding blue-collar labor risky for urban households.',
    'Local Accelerator Pitch Logs',
    [7.2, 8.6, 6.1, 7.8, 7.4],
    192,
  ],
  [
    "B2B SaaS Cross-Border Scale Restrictions (The 'Country-Risk' Pitch Wall)",
    'Compliance',
    'Local high-growth technology builders generating early enterprise validation but facing outright VC check rejections solely due to national structural risk tags.',
    'LinkedIn Founder Failure Retrospectives',
    [9.6, 6.5, 8.5, 5.2, 7.4],
    233,
  ],
  [
    'Real-Time Ride-Hailing Price Surging Anomalies & Arbitrary Cancellations',
    'Logistics',
    'InDrive/Yango driver matching software dealing with highly volatile fare manipulations where riders are stranded due to drivers fishing for manual off-app cash bumps.',
    'X Mobility Rants',
    [7.1, 9.1, 4.8, 8.6, 7.4],
    301,
  ],
  [
    'Freelancer Foreign Remittance Account Suspension Under AML Guidelines',
    'Compliance',
    'Inconsistent enforcement of Anti-Money Laundering tags by local retail bank compliance desks, freezing high-volume foreign currency inflows for legitimate tech workers.',
    'Pakistan IT Association Advisory',
    [9.0, 7.8, 7.0, 6.2, 7.5],
    268,
  ],
  [
    'EdTech Virtual Learning Platform Engagement Lapses & Broadband Friction',
    'Infrastructure',
    'Local digital learning setups failing to build proper low-bandwidth fallback protocols, excluding students in peripheral cities from stable live classroom streaming.',
    'Academic Tech Audits',
    [6.9, 8.4, 5.9, 7.5, 7.1],
    147,
  ],
  [
    'Micro-SME Automated Invoice Matching & Reconciliation Overhead',
    'FinTech',
    'Small trading houses losing up to 10 hours weekly performing manual invoice mapping because international enterprise ERP systems are prohibitively expensive.',
    'r/PakistaniTech Small Business Polls',
    [7.3, 8.7, 6.9, 8.3, 7.8],
    239,
  ],
  [
    'Tech Venture Attrition & University Curriculum AI Skew Lapses',
    'Infrastructure',
    'Local computing graduates entering the market without functional training in modern workflows (Inference Engineering/LLM Tuning), forcing startups to endure expensive 6-month internal bootcamps.',
    'P@SHA Human Capital Surveys',
    [8.1, 7.4, 7.3, 7.0, 7.4],
    211,
  ],
]

export const SEED_ROWS: SheetRow[] = SEED.map(
  ([title, category, description, source, [severity, tam, whitespace, frequency, friction], upvotes], i) => ({
    id: `mur-${String(i + 1).padStart(3, '0')}`,
    title,
    category,
    description,
    source,
    severity,
    tam,
    whitespace,
    frequency,
    friction_index: friction,
    upvotes,
  }),
)
