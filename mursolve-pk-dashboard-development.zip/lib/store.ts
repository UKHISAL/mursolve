import 'server-only'
import {
  SEED_ROWS,
  SHEET_COLUMNS,
  problemFromSheetRow,
  type Category,
  type Problem,
  type Submission,
} from './problems'

interface Store {
  problems: Problem[]
  submissions: Submission[]
}

// In-memory store kept on globalThis so it survives hot reloads in dev.
// Swap these functions for a database or sheet fetch without touching the UI.
const globalStore = globalThis as unknown as { __mursolveV3?: Store }

function store(): Store {
  if (!globalStore.__mursolveV3) {
    globalStore.__mursolveV3 = {
      problems: SEED_ROWS.map(problemFromSheetRow).filter((p): p is Problem => p !== null),
      submissions: [],
    }
  }
  return globalStore.__mursolveV3
}

export function listProblems(): Problem[] {
  return [...store().problems].sort((a, b) => b.frictionIndex - a.frictionIndex || b.upvotes - a.upvotes)
}

export function upvoteProblem(id: string, delta: 1 | -1): Problem | null {
  const problem = store().problems.find((p) => p.id === id)
  if (!problem) return null
  problem.upvotes = Math.max(0, problem.upvotes + delta)
  return problem
}

export function deleteProblem(id: string): boolean {
  const s = store()
  const before = s.problems.length
  s.problems = s.problems.filter((p) => p.id !== id)
  return s.problems.length < before
}

export function overrideFrictionIndex(id: string, score: number): Problem | null {
  const problem = store().problems.find((p) => p.id === id)
  if (!problem) return null
  problem.frictionIndex = score
  problem.frictionOverridden = true
  return problem
}

export function addSubmission(input: {
  title: string
  category: Category
  details: string
  contact: string
}): Submission {
  const submission: Submission = {
    id: `sub-${crypto.randomUUID().slice(0, 8)}`,
    ...input,
    createdAt: new Date().toISOString(),
  }
  store().submissions.unshift(submission)
  return submission
}

export function listSubmissions(): Submission[] {
  return store().submissions
}

export function deleteSubmission(id: string): boolean {
  const s = store()
  const before = s.submissions.length
  s.submissions = s.submissions.filter((x) => x.id !== id)
  return s.submissions.length < before
}

export function rawConfig() {
  return {
    source: 'in-memory (seeded from SEED_ROWS)',
    columns: SHEET_COLUMNS as string[],
    rows: store().problems.map((p) => ({
      id: p.id,
      title: p.title,
      category: p.category,
      description: p.description,
      source: p.source,
      severity: p.scores.severity,
      tam: p.scores.tam,
      whitespace: p.scores.whitespace,
      frequency: p.scores.frequency,
      friction_index: p.frictionIndex,
      upvotes: p.upvotes,
    })),
    pendingSubmissions: store().submissions,
  }
}
