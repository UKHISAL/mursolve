import 'server-only'
import { createHmac, timingSafeEqual } from 'node:crypto'
import { cookies } from 'next/headers'

export const ADMIN_COOKIE = 'mursolve_admin'
const SESSION_TTL_SECONDS = 60 * 60 * 2

function secret(): string | null {
  const password = process.env.ADMIN_PASSWORD
  if (!password) return null
  return process.env.ADMIN_SESSION_SECRET || `mursolve:${password}`
}

function sign(payload: string, key: string) {
  return createHmac('sha256', key).update(payload).digest('base64url')
}

function safeEqual(a: string, b: string) {
  const ab = Buffer.from(a)
  const bb = Buffer.from(b)
  if (ab.length !== bb.length) {
    timingSafeEqual(ab, ab)
    return false
  }
  return timingSafeEqual(ab, bb)
}

export function isAdminConfigured() {
  return Boolean(process.env.ADMIN_PASSWORD)
}

export function verifyPassword(candidate: string): boolean {
  const password = process.env.ADMIN_PASSWORD
  if (!password || typeof candidate !== 'string') return false
  const key = 'mursolve-pw-compare'
  return safeEqual(sign(candidate, key), sign(password, key))
}

export function createSessionToken(): string {
  const key = secret()
  if (!key) throw new Error('ADMIN_PASSWORD is not configured')
  const expires = Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS
  const payload = `admin.${expires}`
  return `${payload}.${sign(payload, key)}`
}

function verifySessionToken(token: string | undefined): boolean {
  const key = secret()
  if (!key || !token) return false
  const parts = token.split('.')
  if (parts.length !== 3) return false
  const [role, expires, signature] = parts
  if (role !== 'admin') return false
  if (Number(expires) < Math.floor(Date.now() / 1000)) return false
  return safeEqual(signature, sign(`${role}.${expires}`, key))
}

export async function isAdmin(): Promise<boolean> {
  const jar = await cookies()
  return verifySessionToken(jar.get(ADMIN_COOKIE)?.value)
}

export const sessionCookieOptions = {
  httpOnly: true,
  secure: true,
  sameSite: 'none' as const,
  path: '/',
  maxAge: SESSION_TTL_SECONDS,
}

const attempts = new Map<string, { count: number; resetAt: number }>()

export function rateLimitLogin(ip: string): boolean {
  const now = Date.now()
  const entry = attempts.get(ip)
  if (!entry || entry.resetAt < now) {
    attempts.set(ip, { count: 1, resetAt: now + 10 * 60 * 1000 })
    return true
  }
  entry.count += 1
  return entry.count <= 5
}
