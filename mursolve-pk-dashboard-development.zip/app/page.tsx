import { Dashboard } from '@/components/mursolve/dashboard'
import { listProblems } from '@/lib/store'

export const dynamic = 'force-dynamic'

export default function Page() {
  return <Dashboard initialProblems={listProblems()} />
}
