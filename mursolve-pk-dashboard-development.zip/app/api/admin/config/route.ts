import { NextResponse } from 'next/server'
import { isAdmin } from '@/lib/admin-auth'
import { deleteSubmission, rawConfig } from '@/lib/store'

export const dynamic = 'force-dynamic'

export async function GET() {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: 'Admin authentication required.' }, { status: 401 })
  }
  return NextResponse.json(rawConfig())
}

export async function DELETE(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: 'Admin authentication required.' }, { status: 401 })
  }
  const id = new URL(request.url).searchParams.get('submission')
  if (!id || !deleteSubmission(id)) return NextResponse.json({ error: 'Not found.' }, { status: 404 })
  return NextResponse.json({ ok: true })
}
