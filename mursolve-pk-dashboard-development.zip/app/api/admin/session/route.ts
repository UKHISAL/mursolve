import { NextResponse } from 'next/server'
import {
  ADMIN_COOKIE,
  createSessionToken,
  isAdmin,
  isAdminConfigured,
  rateLimitLogin,
  sessionCookieOptions,
  verifyPassword,
} from '@/lib/admin-auth'

export const dynamic = 'force-dynamic'

export async function GET() {
  return NextResponse.json({ authenticated: await isAdmin(), configured: isAdminConfigured() })
}

export async function POST(request: Request) {
  if (!isAdminConfigured()) {
    return NextResponse.json(
      { error: 'Admin access is not configured. Set ADMIN_PASSWORD in project variables.' },
      { status: 503 },
    )
  }

  const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown'
  if (!rateLimitLogin(ip)) {
    return NextResponse.json({ error: 'Too many attempts. Try again in 10 minutes.' }, { status: 429 })
  }

  const body = await request.json().catch(() => null)
  if (!verifyPassword(body?.password ?? '')) {
    await new Promise((r) => setTimeout(r, 400))
    return NextResponse.json({ error: 'Incorrect password.' }, { status: 401 })
  }

  const response = NextResponse.json({ authenticated: true })
  response.cookies.set(ADMIN_COOKIE, createSessionToken(), sessionCookieOptions)
  return response
}

export async function DELETE() {
  const response = NextResponse.json({ authenticated: false })
  response.cookies.set(ADMIN_COOKIE, '', { ...sessionCookieOptions, maxAge: 0 })
  return response
}
