import { NextResponse } from 'next/server'
import { isAdmin } from '@/lib/admin-auth'
import { clampScore } from '@/lib/problems'
import { deleteProblem, overrideFrictionIndex } from '@/lib/store'

const unauthorized = () => NextResponse.json({ error: 'Admin authentication required.' }, { status: 401 })

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin())) return unauthorized()
  const { id } = await params
  if (!deleteProblem(id)) return NextResponse.json({ error: 'Not found.' }, { status: 404 })
  return NextResponse.json({ ok: true })
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin())) return unauthorized()
  const { id } = await params
  const body = await request.json().catch(() => null)
  const score = Number(body?.frictionIndex)
  if (!Number.isFinite(score) || score < 0 || score > 10) {
    return NextResponse.json({ error: 'Friction Index must be a number from 0 to 10.' }, { status: 400 })
  }
  const problem = overrideFrictionIndex(id, clampScore(score))
  if (!problem) return NextResponse.json({ error: 'Not found.' }, { status: 404 })
  return NextResponse.json({ problem })
}
