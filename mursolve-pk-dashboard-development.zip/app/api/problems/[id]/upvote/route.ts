import { NextResponse } from 'next/server'
import { upvoteProblem } from '@/lib/store'

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const body = await request.json().catch(() => null)
  const delta = body?.undo === true ? -1 : 1
  const problem = upvoteProblem(id, delta)
  if (!problem) return NextResponse.json({ error: 'Not found.' }, { status: 404 })
  return NextResponse.json({ upvotes: problem.upvotes })
}
