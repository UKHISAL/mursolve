import { NextResponse } from 'next/server'
import { isCategory } from '@/lib/problems'
import { addSubmission, listProblems } from '@/lib/store'

export const dynamic = 'force-dynamic'

export async function GET() {
  return NextResponse.json({ problems: listProblems() })
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null)
  const title = typeof body?.title === 'string' ? body.title.trim() : ''
  const details = typeof body?.details === 'string' ? body.details.trim() : ''
  const contact = typeof body?.contact === 'string' ? body.contact.trim() : ''

  if (title.length < 15 || title.length > 240) {
    return NextResponse.json({ error: 'Title must be between 15 and 240 characters.' }, { status: 400 })
  }
  if (!isCategory(body?.category)) {
    return NextResponse.json({ error: 'Pick a valid category.' }, { status: 400 })
  }
  if (details.length > 2000 || contact.length > 120) {
    return NextResponse.json({ error: 'Details or contact is too long.' }, { status: 400 })
  }

  const submission = addSubmission({ title, category: body.category, details, contact })
  return NextResponse.json({ ok: true, id: submission.id }, { status: 201 })
}
