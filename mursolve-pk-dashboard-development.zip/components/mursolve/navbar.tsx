import { Plus } from 'lucide-react'

export function Navbar({ onSubmit }: { onSubmit: () => void }) {
  return (
    <header className="sticky top-0 z-30 border-b border-primary/20 bg-background/95 backdrop-blur">
      <nav className="mx-auto flex h-20 max-w-6xl items-center justify-between px-5 md:px-8" aria-label="Main">
        <a href="#top" className="text-2xl font-black tracking-tighter text-primary md:text-4xl">
          Mursolve<span className="font-extrabold opacity-60">.com</span>
        </a>
        <button
          type="button"
          onClick={onSubmit}
          className="flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        >
          <Plus className="size-4" aria-hidden />
          <span className="hidden sm:inline">Submit a Problem</span>
          <span className="sm:hidden">Submit</span>
        </button>
      </nav>
    </header>
  )
}
