'use client'

import { useDeferredValue, useMemo, useState } from 'react'
import { SearchX } from 'lucide-react'
import type { Problem } from '@/lib/problems'
import { CATEGORIES } from '@/lib/problems'
import { api, useAdminSession, useProblems } from '@/lib/hooks'
import { Navbar } from './navbar'
import { CenteredHero } from './centered-hero'
import { SearchFilters, type Filter } from './search-filters'
import { ProblemRow } from './problem-row'
import { SubmitModal } from './submit-modal'
import { AdminAuthModal } from './admin-auth-modal'
import { AdminConsole } from './admin-console'
import { Footer } from './footer'

export function Dashboard({ initialProblems }: { initialProblems: Problem[] }) {
  const { data, mutate } = useProblems(initialProblems)
  const { data: session, mutate: mutateSession } = useAdminSession()
  const problems = data?.problems ?? []
  const isAdmin = session?.authenticated === true

  const [query, setQuery] = useState('')
  const deferredQuery = useDeferredValue(query)
  const [filter, setFilter] = useState<Filter>('All')
  const [openId, setOpenId] = useState<string | null>(null)
  const [voted, setVoted] = useState<Set<string>>(new Set())
  const [submitOpen, setSubmitOpen] = useState(false)
  const [authOpen, setAuthOpen] = useState(false)

  const searched = useMemo(() => {
    const q = deferredQuery.trim().toLowerCase()
    if (!q) return problems
    return problems.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.source.toLowerCase().includes(q),
    )
  }, [problems, deferredQuery])

  function scrollToRegistry() {
    document.getElementById('registry')?.scrollIntoView({ behavior: 'smooth' })
  }

  function showTopProblems() {
    setQuery('')
    setFilter('All')
    setOpenId(problems[0]?.id ?? null)
    scrollToRegistry()
  }

  function browseEverything() {
    setQuery('')
    setFilter('All')
    setOpenId(null)
    scrollToRegistry()
  }

  const counts = useMemo(() => {
    const result = { All: searched.length } as Record<Filter, number>
    for (const c of CATEGORIES) result[c] = searched.filter((p) => p.category === c).length
    return result
  }, [searched])

  const visible = filter === 'All' ? searched : searched.filter((p) => p.category === filter)

  function patchProblem(id: string, patch: Partial<Problem>) {
    return {
      problems: problems.map((p) => (p.id === id ? { ...p, ...patch } : p)),
    }
  }

  async function handleUpvote(problem: Problem) {
    const undo = voted.has(problem.id)
    setVoted((prev) => {
      const next = new Set(prev)
      if (undo) next.delete(problem.id)
      else next.add(problem.id)
      return next
    })
    await mutate(
      async () => {
        const res = await api<{ upvotes: number }>(`/api/problems/${problem.id}/upvote`, {
          method: 'POST',
          body: JSON.stringify({ undo }),
        })
        return patchProblem(problem.id, { upvotes: res.upvotes })
      },
      {
        optimisticData: patchProblem(problem.id, { upvotes: problem.upvotes + (undo ? -1 : 1) }),
        rollbackOnError: true,
        revalidate: false,
      },
    )
  }

  async function handleAdminError(err: unknown) {
    if (err instanceof Error && 'status' in err && err.status === 401) {
      await mutateSession()
      setAuthOpen(true)
    }
    throw err
  }

  async function handleDelete(id: string) {
    try {
      await api(`/api/problems/${id}`, { method: 'DELETE' })
      setOpenId(null)
      await mutate({ problems: problems.filter((p) => p.id !== id) }, { revalidate: true })
    } catch (err) {
      await handleAdminError(err)
    }
  }

  async function handleOverride(id: string, score: number) {
    try {
      await api(`/api/problems/${id}`, { method: 'PATCH', body: JSON.stringify({ frictionIndex: score }) })
      await mutate()
    } catch (err) {
      await handleAdminError(err)
    }
  }

  async function handleLogout() {
    await api('/api/admin/session', { method: 'DELETE' })
    await mutateSession()
  }

  return (
    <>
      <Navbar onSubmit={() => setSubmitOpen(true)} />
      {isAdmin && <AdminConsole onLogout={handleLogout} />}

      <main>
        <CenteredHero problemCount={problems.length} onShowTop={showTopProblems} onBrowseAll={browseEverything} />

        <section id="registry" aria-labelledby="registry-title" className="scroll-mt-20 border-t border-primary/20 bg-muted">
          <div className="mx-auto flex max-w-6xl flex-col gap-10 px-5 py-16 md:px-8 md:py-24">
            <div className="flex flex-col gap-3">
              <h2 id="registry-title" className="text-3xl font-extrabold tracking-tight text-primary text-balance md:text-5xl">
                The Operational Problem Registry
              </h2>
              <p className="max-w-xl leading-relaxed text-muted-foreground text-pretty">
                Ranked by The Friction Index. Open a problem to see its evidence and sub-scores, then upvote it to
                validate.
              </p>
            </div>

            <SearchFilters
              query={query}
              onQueryChange={setQuery}
              filter={filter}
              onFilterChange={setFilter}
              counts={counts}
            />

            <div className="overflow-hidden rounded-3xl border border-primary bg-background">
              {visible.length > 0 ? (
                <ul aria-live="polite">
                  {visible.map((problem, index) => (
                    <ProblemRow
                      key={problem.id}
                      problem={problem}
                      index={index}
                      open={openId === problem.id}
                      onToggle={() => setOpenId((cur) => (cur === problem.id ? null : problem.id))}
                      voted={voted.has(problem.id)}
                      onUpvote={() => handleUpvote(problem)}
                      isAdmin={isAdmin}
                      onDelete={() => handleDelete(problem.id)}
                      onOverride={(score) => handleOverride(problem.id, score)}
                    />
                  ))}
                </ul>
              ) : (
                <div className="flex flex-col items-center gap-3 px-6 py-20 text-center">
                  <SearchX className="size-8 text-primary" aria-hidden />
                  <p className="font-semibold text-foreground">No problem matches that search.</p>
                  <button
                    type="button"
                    onClick={() => {
                      setQuery('')
                      setFilter('All')
                    }}
                    className="text-sm font-semibold text-primary underline underline-offset-4"
                  >
                    Reset filters
                  </button>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>

      <Footer onAdmin={() => (isAdmin ? window.scrollTo({ top: 0, behavior: 'smooth' }) : setAuthOpen(true))} isAdmin={isAdmin} />

      <SubmitModal open={submitOpen} onClose={() => setSubmitOpen(false)} />
      <AdminAuthModal
        open={authOpen}
        configured={session?.configured ?? true}
        onClose={() => setAuthOpen(false)}
        onAuthenticated={async () => {
          await mutateSession()
          setAuthOpen(false)
        }}
      />
    </>
  )
}
