import { Lock } from 'lucide-react'

export function Footer({ onAdmin, isAdmin }: { onAdmin: () => void; isAdmin: boolean }) {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-5 py-10 md:flex-row md:items-center md:justify-between md:px-8">
        <div className="flex flex-col gap-1">
          <span className="text-lg font-extrabold tracking-tight text-primary">Mursolve.com</span>
          <span className="text-sm text-muted-foreground">The global wishlist for founders — one scored problem at a time.</span>
        </div>
        <nav aria-label="Footer" className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
          <a href="#registry" className="hover:text-primary">
            Registry
          </a>
          <a href="#top" className="hover:text-primary">
            Top
          </a>
          <span>© {new Date().getFullYear()} Mursolve</span>
          <button
            type="button"
            onClick={onAdmin}
            className="flex items-center gap-1 text-xs text-muted-foreground/70 hover:text-primary"
          >
            <Lock className="size-3" aria-hidden />
            {isAdmin ? 'Admin active' : 'Admin Portal'}
          </button>
        </nav>
      </div>
    </footer>
  )
}
