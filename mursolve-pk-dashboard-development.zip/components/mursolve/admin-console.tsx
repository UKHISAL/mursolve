'use client'

import { useState } from 'react'
import { FileJson, Inbox, LogOut, Table2, Trash2 } from 'lucide-react'
import { api, useAdminConfig } from '@/lib/hooks'
import { Modal } from './modal'

export function AdminConsole({ onLogout }: { onLogout: () => void }) {
  const [sheetOpen, setSheetOpen] = useState(false)
  const { data, mutate } = useAdminConfig(true)
  const pending = data?.pendingSubmissions ?? []

  async function dismiss(id: string) {
    await api(`/api/admin/config?submission=${encodeURIComponent(id)}`, { method: 'DELETE' })
    mutate()
  }

  return (
    <section aria-label="Admin console" className="border-y border-primary bg-primary text-primary-foreground">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 py-4 md:flex-row md:items-center md:justify-between md:px-8">
        <p className="text-sm font-semibold">
          Admin layer unlocked
          <span className="ml-2 font-normal opacity-75">Open any row to override scores or hard-delete.</span>
        </p>
        <div className="flex flex-wrap items-center gap-2">
          <span className="flex items-center gap-1.5 rounded-full border border-primary-foreground/30 px-3 py-1.5 text-xs font-semibold">
            <Inbox className="size-3.5" aria-hidden />
            {pending.length} pending
          </span>
          <button
            type="button"
            onClick={() => {
              mutate()
              setSheetOpen(true)
            }}
            className="flex items-center gap-1.5 rounded-full bg-primary-foreground px-3 py-1.5 text-xs font-semibold text-primary"
          >
            <Table2 className="size-3.5" aria-hidden />
            View raw data sheet
          </button>
          <button
            type="button"
            onClick={onLogout}
            className="flex items-center gap-1.5 rounded-full border border-primary-foreground/30 px-3 py-1.5 text-xs font-semibold hover:bg-primary-foreground/10"
          >
            <LogOut className="size-3.5" aria-hidden />
            Lock
          </button>
        </div>
      </div>

      <Modal
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        title="Raw data sheet configuration"
        description={data ? `Source: ${data.source}` : 'Loading…'}
        size="lg"
      >
        {data && (
          <div className="flex flex-col gap-6">
            <div className="overflow-x-auto rounded-xl border border-border">
              <table className="w-full min-w-[640px] text-left text-sm">
                <thead className="bg-muted">
                  <tr>
                    {data.columns.map((c) => (
                      <th key={c} scope="col" className="px-3 py-2 font-mono text-xs font-semibold text-primary">
                        {c}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.rows.map((row) => (
                    <tr key={String(row.id)} className="border-t border-border">
                      {data.columns.map((c) => (
                        <td key={c} className="max-w-[260px] truncate px-3 py-2 font-mono text-xs text-foreground">
                          {row[c]}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex flex-col gap-3">
              <h3 className="flex items-center gap-2 text-sm font-bold text-primary">
                <Inbox className="size-4" aria-hidden />
                Pending submissions
              </h3>
              {pending.length === 0 ? (
                <p className="text-sm text-muted-foreground">No submissions in the queue.</p>
              ) : (
                <ul className="flex flex-col divide-y divide-border rounded-xl border border-border">
                  {pending.map((s) => (
                    <li key={s.id} className="flex items-start justify-between gap-4 p-3">
                      <div className="flex flex-col gap-1">
                        <p className="text-sm font-semibold text-foreground">{s.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {s.category}
                          {s.contact ? ` · ${s.contact}` : ''}
                        </p>
                        {s.details && <p className="text-xs leading-relaxed text-muted-foreground">{s.details}</p>}
                      </div>
                      <button
                        type="button"
                        onClick={() => dismiss(s.id)}
                        className="flex size-8 shrink-0 items-center justify-center rounded-lg border border-border text-destructive hover:bg-destructive/5"
                      >
                        <Trash2 className="size-4" aria-hidden />
                        <span className="sr-only">Dismiss submission</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <details className="rounded-xl border border-border">
              <summary className="flex cursor-pointer items-center gap-2 px-4 py-3 text-sm font-semibold text-primary">
                <FileJson className="size-4" aria-hidden />
                JSON export
              </summary>
              <pre className="max-h-72 overflow-auto border-t border-border bg-muted p-4 font-mono text-xs leading-relaxed text-foreground">
                {JSON.stringify(data.rows, null, 2)}
              </pre>
            </details>
          </div>
        )}
      </Modal>
    </section>
  )
}
