'use client'

import { useId, useState } from 'react'
import { ArrowBigUp, Database, Lock, Plus, Trash2 } from 'lucide-react'
import type { Problem, ProblemScores } from '@/lib/problems'

const SCORE_LABELS: { key: keyof ProblemScores; label: string; hint: string }[] = [
  { key: 'severity', label: 'Severity', hint: 'How much it hurts' },
  { key: 'tam', label: 'TAM', hint: 'How many it touches' },
  { key: 'whitespace', label: 'Whitespace', hint: 'How unsolved it is' },
  { key: 'frequency', label: 'Frequency', hint: 'How often it happens' },
]

const formatScore = (n: number) => n.toFixed(1)

interface ProblemRowProps {
  problem: Problem
  index: number
  open: boolean
  onToggle: () => void
  voted: boolean
  onUpvote: () => void
  isAdmin: boolean
  onDelete: () => Promise<void>
  onOverride: (score: number) => Promise<void>
}

export function ProblemRow({
  problem,
  index,
  open,
  onToggle,
  voted,
  onUpvote,
  isAdmin,
  onDelete,
  onOverride,
}: ProblemRowProps) {
  const panelId = useId()
  const buttonId = useId()

  return (
    <li
      id={`problem-${problem.id}`}
      className={`scroll-mt-28 border-b border-primary/20 transition-colors last:border-b-0 ${open ? 'bg-muted' : 'bg-background hover:bg-muted'}`}
    >
      <h3>
        <button
          id={buttonId}
          type="button"
          aria-expanded={open}
          aria-controls={panelId}
          onClick={onToggle}
          className="flex w-full items-center gap-4 px-4 py-6 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring md:gap-8 md:px-6 md:py-7"
        >
          <span className="hidden w-8 shrink-0 text-sm font-semibold text-primary/60 tabular-nums md:block">
            {String(index + 1).padStart(2, '0')}
          </span>
          <span className="flex-1 text-lg font-semibold leading-snug tracking-tight text-foreground text-pretty md:text-xl">
            {problem.title}
          </span>
          <span className="hidden shrink-0 text-right text-sm font-bold text-primary tabular-nums lg:block">
            {formatScore(problem.frictionIndex)}
            <span className="block text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
              Friction
            </span>
          </span>
          <span className="hidden shrink-0 rounded-full border border-primary/30 px-3 py-1 text-xs font-semibold text-primary sm:inline">
            {problem.category}
          </span>
          <span
            className={`flex size-10 shrink-0 items-center justify-center rounded-full border transition-all duration-300 md:size-11 ${
              open ? 'rotate-45 border-primary bg-primary text-primary-foreground' : 'border-primary/40 text-primary'
            }`}
            aria-hidden
          >
            <Plus className="size-5" />
          </span>
        </button>
      </h3>

      <div
        id={panelId}
        role="region"
        aria-labelledby={buttonId}
        className={`grid transition-[grid-template-rows,opacity] duration-500 ease-out ${
          open ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
        }`}
        inert={!open}
      >
        <div className="overflow-hidden">
          <div className="flex flex-col gap-6 px-4 pb-8 md:pr-6 md:pl-22">
            <span className="w-fit rounded-full border border-primary/30 px-3 py-1 text-xs font-semibold text-primary sm:hidden">
              {problem.category}
            </span>

            {problem.description && (
              <div className="flex max-w-3xl flex-col gap-2">
                <p className="leading-relaxed text-foreground text-pretty">{problem.description}</p>
                {problem.source && (
                  <p className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                    <Database className="size-3.5 text-primary" aria-hidden />
                    Source: {problem.source}
                  </p>
                )}
              </div>
            )}

            <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-primary bg-primary/20 lg:grid-cols-4">
              {SCORE_LABELS.map(({ key, label, hint }) => {
                const value = problem.scores[key]
                return (
                  <div key={key} className="flex flex-col gap-3 bg-background p-4 md:p-5">
                    <dt className="text-[11px] font-bold uppercase tracking-[0.14em] text-primary">{label}</dt>
                    <dd className="flex flex-col gap-2">
                      <span className="text-3xl font-extrabold tracking-tight text-foreground tabular-nums">
                        {formatScore(value)}
                        <span className="text-base font-semibold text-muted-foreground">/10</span>
                      </span>
                      <span className="h-1.5 w-full overflow-hidden rounded-full bg-accent" aria-hidden>
                        <span
                          className="block h-full rounded-full bg-primary transition-[width] duration-700 ease-out"
                          style={{ width: open ? `${value * 10}%` : '0%' }}
                        />
                      </span>
                      <span className="text-xs text-muted-foreground">{hint}</span>
                    </dd>
                  </div>
                )
              })}
            </dl>

            <div className="flex flex-wrap items-end justify-between gap-4">
              <div className="flex flex-col gap-1">
                <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-primary">
                  The Friction Index{problem.frictionOverridden ? ' · admin set' : ''}
                </span>
                <span className="text-5xl font-extrabold tracking-tight text-primary tabular-nums">
                  {formatScore(problem.frictionIndex)}
                  <span className="text-xl font-bold text-primary/50">/10</span>
                </span>
              </div>

              <button
                type="button"
                onClick={onUpvote}
                aria-pressed={voted}
                className={`flex items-center gap-2 rounded-full border px-5 py-3 text-sm font-semibold transition-colors focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${
                  voted
                    ? 'border-primary bg-primary text-primary-foreground'
                    : 'border-primary bg-background text-primary hover:bg-accent'
                }`}
              >
                <ArrowBigUp className={`size-5 ${voted ? 'fill-current' : ''}`} aria-hidden />
                {voted ? 'Upvoted' : 'Upvote'}
                <span className="tabular-nums opacity-80">{problem.upvotes.toLocaleString()}</span>
              </button>
            </div>

            {isAdmin && <AdminRowControls problem={problem} onDelete={onDelete} onOverride={onOverride} />}
          </div>
        </div>
      </div>
    </li>
  )
}

function AdminRowControls({
  problem,
  onDelete,
  onOverride,
}: {
  problem: Problem
  onDelete: () => Promise<void>
  onOverride: (score: number) => Promise<void>
}) {
  const [value, setValue] = useState(String(problem.frictionIndex))
  const [confirming, setConfirming] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const inputId = useId()

  async function run(fn: () => Promise<void>) {
    setBusy(true)
    setError(null)
    try {
      await fn()
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Action failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-dashed border-primary/40 bg-background p-4">
      <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.14em] text-primary">
        <Lock className="size-3.5" aria-hidden />
        Admin controls
      </p>
      <div className="flex flex-wrap items-center gap-3">
        <form
          className="flex items-center gap-2"
          onSubmit={(e) => {
            e.preventDefault()
            const n = Number(value)
            if (!Number.isFinite(n) || n < 0 || n > 10) {
              setError('Enter a number from 0 to 10.')
              return
            }
            run(() => onOverride(n))
          }}
        >
          <label htmlFor={inputId} className="text-sm font-medium text-foreground">
            Override Friction Index
          </label>
          <input
            id={inputId}
            type="number"
            min={0}
            max={10}
            step={0.1}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            className="w-20 rounded-lg border border-input bg-background px-2.5 py-1.5 text-sm tabular-nums focus:border-primary focus:outline-none"
          />
          <button
            type="submit"
            disabled={busy}
            className="rounded-lg bg-primary px-3 py-1.5 text-sm font-semibold text-primary-foreground disabled:opacity-50"
          >
            Save
          </button>
        </form>

        <div className="ml-auto flex items-center gap-2">
          {confirming ? (
            <>
              <span className="text-sm text-destructive">Permanently delete?</span>
              <button
                type="button"
                disabled={busy}
                onClick={() => run(onDelete)}
                className="rounded-lg bg-destructive px-3 py-1.5 text-sm font-semibold text-primary-foreground disabled:opacity-50"
              >
                Delete
              </button>
              <button
                type="button"
                onClick={() => setConfirming(false)}
                className="rounded-lg border border-border px-3 py-1.5 text-sm font-semibold"
              >
                Cancel
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={() => setConfirming(true)}
              className="flex items-center gap-1.5 rounded-lg border border-destructive/40 px-3 py-1.5 text-sm font-semibold text-destructive hover:bg-destructive/5"
            >
              <Trash2 className="size-4" aria-hidden />
              Hard delete
            </button>
          )}
        </div>
      </div>
      {error && (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      )}
    </div>
  )
}
