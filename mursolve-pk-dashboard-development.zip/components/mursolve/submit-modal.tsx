'use client'

import { useState } from 'react'
import { CheckCircle2 } from 'lucide-react'
import { CATEGORIES } from '@/lib/problems'
import { api } from '@/lib/hooks'
import { Modal, inputClass, labelClass } from './modal'

export function SubmitModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [status, setStatus] = useState<'idle' | 'sending' | 'done'>('idle')
  const [error, setError] = useState<string | null>(null)

  function close() {
    onClose()
    setTimeout(() => {
      setStatus('idle')
      setError(null)
    }, 200)
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    setStatus('sending')
    setError(null)
    try {
      await api('/api/problems', {
        method: 'POST',
        body: JSON.stringify({
          title: form.get('title'),
          category: form.get('category'),
          details: form.get('details'),
          contact: form.get('contact'),
        }),
      })
      setStatus('done')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not submit')
      setStatus('idle')
    }
  }

  return (
    <Modal
      open={open}
      onClose={close}
      title={status === 'done' ? 'Problem received' : 'Submit a Problem'}
      description={
        status === 'done'
          ? undefined
          : 'Frame it as a question. Our reviewers score it before it enters the public registry.'
      }
    >
      {status === 'done' ? (
        <div className="flex flex-col items-start gap-4">
          <CheckCircle2 className="size-10 text-primary" aria-hidden />
          <p className="leading-relaxed text-muted-foreground">
            Shukriya. Your problem is in the review queue and will be scored on severity, TAM, whitespace and
            frequency before it&apos;s published.
          </p>
          <button
            type="button"
            onClick={close}
            className="rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground"
          >
            Back to registry
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="flex flex-col gap-5">
          <div className="flex flex-col gap-2">
            <label htmlFor="sub-title" className={labelClass}>
              Problem statement
            </label>
            <textarea
              id="sub-title"
              name="title"
              required
              minLength={15}
              maxLength={240}
              rows={2}
              placeholder="Why do…?"
              className={`${inputClass} resize-none`}
            />
          </div>
          <div className="flex flex-col gap-2">
            <label htmlFor="sub-category" className={labelClass}>
              Category
            </label>
            <select id="sub-category" name="category" required defaultValue="" className={inputClass}>
              <option value="" disabled>
                Choose a category
              </option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-2">
            <label htmlFor="sub-details" className={labelClass}>
              Context <span className="font-medium normal-case tracking-normal text-muted-foreground">(optional)</span>
            </label>
            <textarea
              id="sub-details"
              name="details"
              maxLength={2000}
              rows={3}
              placeholder="Who faces it, how often, what it costs them."
              className={`${inputClass} resize-none`}
            />
          </div>
          <div className="flex flex-col gap-2">
            <label htmlFor="sub-contact" className={labelClass}>
              Email or handle <span className="font-medium normal-case tracking-normal text-muted-foreground">(optional)</span>
            </label>
            <input id="sub-contact" name="contact" maxLength={120} className={inputClass} />
          </div>
          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}
          <button
            type="submit"
            disabled={status === 'sending'}
            className="rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
          >
            {status === 'sending' ? 'Submitting…' : 'Submit for review'}
          </button>
        </form>
      )}
    </Modal>
  )
}
