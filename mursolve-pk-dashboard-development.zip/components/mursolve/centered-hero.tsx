import { ArrowDown, ArrowRight } from 'lucide-react'

interface CenteredHeroProps {
  problemCount: number
  onShowTop: () => void
  onBrowseAll: () => void
}

export function CenteredHero({ problemCount, onShowTop, onBrowseAll }: CenteredHeroProps) {
  return (
    <section id="top" aria-labelledby="hero-title" className="bg-muted">
      <div className="mx-auto flex max-w-5xl flex-col items-center gap-8 px-5 py-20 text-center md:py-32">
        <span className="rounded-full border border-primary bg-background px-4 py-1.5 text-xs font-bold uppercase tracking-[0.18em] text-primary">
          {problemCount} validated problems · Pakistan
        </span>

        <h1
          id="hero-title"
          className="text-4xl font-extrabold leading-[1.05] tracking-tight text-primary text-balance sm:text-5xl md:text-7xl"
        >
          {'MURSOLVE.COM — THE GLOBAL WISHLIST FOR FOUNDERS TO SOLVE'}
        </h1>

        <p className="max-w-2xl text-lg leading-relaxed text-muted-foreground text-pretty md:text-xl">
          Stop guessing what to build. Explore 20 real-world structural inefficiencies and massive consumer market
          bottlenecks validated through actual data streams.
        </p>

        <div className="flex w-full flex-col items-center justify-center gap-3 sm:w-auto sm:flex-row">
          <button
            type="button"
            onClick={onShowTop}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-primary px-7 py-4 text-base font-semibold text-primary-foreground transition-opacity hover:opacity-90 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 sm:w-auto"
          >
            Show Me Top Problems
            <ArrowRight className="size-4" aria-hidden />
          </button>
          <button
            type="button"
            onClick={onBrowseAll}
            className="flex w-full items-center justify-center gap-2 rounded-full border border-primary bg-background px-7 py-4 text-base font-semibold text-primary transition-colors hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 sm:w-auto"
          >
            Browse Everything
            <ArrowDown className="size-4" aria-hidden />
          </button>
        </div>
      </div>
    </section>
  )
}
