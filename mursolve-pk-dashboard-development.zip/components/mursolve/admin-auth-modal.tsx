'use client'

import { useState } from 'react'
import { ShieldCheck } from 'lucide-react'
import { api } from '@/lib/hooks'
import { Modal, inputClass, labelClass } from './modal'

interface AdminAuthModalProps {
  open: boolean
  onClose: () => void
  onAuthenticated: () => void
  configured: boolean
}

export function AdminAuthModal({ open, onClose, onAuthenticated, configured }: AdminAuthModalProps) {
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setBusy(true)
    setError(null)
    try {
      await api('/api/admin/session', { method: 'POST', body: JSON.stringify({ password }) })
      setPassword('')
      onAuthenticated()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Admin Portal"
      description="Restricted area. Destructive operations require a verified admin session."
    >
      <form onSubmit={handleSubmit} className="flex flex-col gap-5">
        <div className="flex items-center gap-3 rounded-xl bg-accent p-4 text-sm text-accent-foreground">
          <ShieldCheck className="size-5 shrink-0" aria-hidden />
          <span className="leading-relaxed">
            Sessions are signed server-side, stored in an HttpOnly cookie, and expire after 2 hours.
          </span>
        </div>
        {!configured && (
          <p role="status" className="text-sm leading-relaxed text-destructive">
            No admin password is configured yet. Add <code className="font-mono">ADMIN_PASSWORD</code> in project
            variables to enable the portal.
          </p>
        )}
        <div className="flex flex-col gap-2">
          <label htmlFor="admin-password" className={labelClass}>
            Admin password
          </label>
          <input
            id="admin-password"
            type="password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={inputClass}
          />
        </div>
        {error && (
          <p role="alert" className="text-sm text-destructive">
            {error}
          </p>
        )}
        <button
          type="submit"
          disabled={busy || !password}
          className="rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
        >
          {busy ? 'Verifying…' : 'Unlock admin layer'}
        </button>
      </form>
    </Modal>
  )
}
