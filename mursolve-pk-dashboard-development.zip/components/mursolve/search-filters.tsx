'use client'

import { Search, X } from 'lucide-react'
import { CATEGORIES, type Category } from '@/lib/problems'

export type Filter = 'All' | Category

interface SearchFiltersProps {
  query: string
  onQueryChange: (q: string) => void
  filter: Filter
  onFilterChange: (f: Filter) => void
  counts: Record<Filter, number>
}

export function SearchFilters({ query, onQueryChange, filter, onFilterChange, counts }: SearchFiltersProps) {
  const filters: Filter[] = ['All', ...CATEGORIES]
  return (
    <div className="flex flex-col gap-5">
      <label className="relative block">
        <span className="sr-only">Search problems</span>
        <Search className="pointer-events-none absolute top-1/2 left-5 size-5 -translate-y-1/2 text-primary" aria-hidden />
        <input
          type="search"
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder="Search problems — wallets, couriers, cards, AML, AgriTech…"
          className="h-14 w-full rounded-full border border-primary bg-background pr-12 pl-14 text-base text-foreground placeholder:text-muted-foreground focus:border-primary focus:bg-background focus:outline-none focus:ring-4 focus:ring-primary/10"
        />
        {query && (
          <button
            type="button"
            onClick={() => onQueryChange('')}
            className="absolute top-1/2 right-4 flex size-7 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground hover:bg-accent hover:text-primary"
          >
            <X className="size-4" aria-hidden />
            <span className="sr-only">Clear search</span>
          </button>
        )}
      </label>

      <div role="tablist" aria-label="Filter by category" className="flex flex-wrap items-center gap-x-6 gap-y-2 px-1">
        {filters.map((f) => {
          const active = filter === f
          return (
            <button
              key={f}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => onFilterChange(f)}
              className={`relative py-1.5 text-sm font-semibold transition-colors ${
                active ? 'text-primary' : 'text-muted-foreground hover:text-primary'
              }`}
            >
              {f}
              <sup className="ml-0.5 text-[10px] font-medium" aria-hidden>
                {counts[f] ?? 0}
              </sup>
              <span className="sr-only">{` (${counts[f] ?? 0})`}</span>
              <span
                className={`absolute inset-x-0 -bottom-0.5 h-0.5 rounded-full bg-primary transition-transform duration-300 ${
                  active ? 'scale-x-100' : 'scale-x-0'
                }`}
                aria-hidden
              />
            </button>
          )
        })}
      </div>
    </div>
  )
}
